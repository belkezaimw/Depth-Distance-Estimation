"""
dfire.utils.drawing
===================
Resolution-aware OpenCV drawing helpers used by both UI windows.
All sizes scale proportionally with image width so the overlay looks
the same whether the image is 416 px or 4000 px wide.
"""

from __future__ import annotations

import cv2
import numpy as np

# ── palette (BGR) ─────────────────────────────────────────────────────────────
class Palette:
    BG      = (18,  20,  26)
    PANEL   = (28,  32,  42)
    BORDER  = (55,  62,  78)
    ACCENT  = (36, 180, 255)
    ORANGE  = (30, 150, 240)
    GREEN   = (55, 210,  90)
    RED     = (55,  55, 220)
    PURPLE  = (200, 75, 175)
    WHITE   = (240, 240, 245)
    GRAY    = (120, 128, 145)
    DARK    = (12,  14,  18)
    YELLOW  = (30, 215, 255)

P = Palette()

FONT  = cv2.FONT_HERSHEY_SIMPLEX
FONTB = cv2.FONT_HERSHEY_DUPLEX


class DrawHelper:
    """
    Stateless drawing helper; all methods take an image and draw on it.
    sc (scale) is computed from image width to keep elements proportional.
    """

    def __init__(self, img_width: int) -> None:
        self.sc = max(1.0, img_width / 900.0)

    # ── primitives ────────────────────────────────────────────────────────────

    @staticmethod
    def text(
        img, s: str, x: int, y: int,
        color=P.WHITE, scale: float = 0.40, thick: int = 1, bold: bool = False,
    ) -> None:
        f = FONTB if bold else FONT
        cv2.putText(img, str(s), (int(x), int(y)), f, scale, color, thick, cv2.LINE_AA)

    @staticmethod
    def semi_rect(
        img, x0: int, y0: int, x1: int, y1: int,
        color=P.DARK, alpha: float = 0.80,
    ) -> None:
        """Semi-transparent filled rectangle."""
        roi = img[y0:y1, x0:x1]
        if roi.size == 0:
            return
        cv2.addWeighted(
            np.full_like(roi, color), alpha,
            roi, 1 - alpha,
            0, roi,
        )

    def badge(
        self, img, s: str, x: int, y: int,
        bg=P.ACCENT, fg=P.DARK, scale: float = 0.40,
    ) -> None:
        (tw, th), _ = cv2.getTextSize(s, FONT, scale, 1)
        pad = 6
        x = int(max(pad, min(x, img.shape[1] - tw - pad * 2 - 2)))
        y = int(max(th + pad + 2, min(y, img.shape[0] - pad - 2)))
        cv2.rectangle(img, (x - pad, y - th - pad), (x + tw + pad, y + pad), bg, -1)
        self.text(img, s, x, y, fg, scale)

    def crosshair(
        self, img, cx: int, cy: int,
        color=P.ORANGE, r: int = 14, thick: int = 2,
    ) -> None:
        r   = max(8, int(r * self.sc))
        th  = max(1, int(thick * self.sc))
        cv2.circle(img, (cx, cy), r, color, th, cv2.LINE_AA)
        cv2.circle(img, (cx, cy), max(2, int(3 * self.sc)), color, -1, cv2.LINE_AA)
        g, e = r + int(5 * self.sc), r + int(18 * self.sc)
        for a, b in [
            ((cx-e, cy), (cx-g, cy)), ((cx+g, cy), (cx+e, cy)),
            ((cx, cy-e), (cx, cy-g)), ((cx, cy+g), (cx, cy+e)),
        ]:
            cv2.line(img, a, b, color, 1, cv2.LINE_AA)

    # ── composite panels ─────────────────────────────────────────────────────

    def info_panel(
        self,
        img,
        dist_str:   str,
        rows:       list[tuple[str, str, tuple]],
        confidence: float = 0.0,
        at_max:     bool  = False,
        max_range:  int   = 0,
    ) -> None:
        """
        Draw the measurement info panel (top-left corner).

        Parameters
        ----------
        dist_str    : formatted primary distance ("1.23 km")
        rows        : list of (label, value, colour) for the detail rows
        confidence  : AI confidence 0-1 for the confidence bar
        at_max      : whether the ray hit the maximum range limit
        max_range   : max range value in metres (for "at max" label)
        """
        sc  = self.sc
        pw  = max(240, int(285 * sc))
        p   = max(8,   int(10  * sc))
        rh  = max(13,  int(15  * sc))
        x0, y0 = p, p
        ph  = p + int(38*sc) + int(22*sc) + len(rows)*rh + p*2 + int(20*sc)

        H, W = img.shape[:2]
        x1 = min(x0 + pw, W - 1)
        y1 = min(y0 + ph, H - 1)

        self.semi_rect(img, x0, y0, x1, y1, P.DARK, 0.82)
        cv2.rectangle(img, (x0, y0), (x1, y1), P.BORDER, 1)
        sep = y0 + int(28 * sc)
        cv2.line(img, (x0, sep), (x1, sep), P.BORDER, 1)

        self.text(img, "DISTANCE FROM CAMERA",
                  x0+p, y0+int(20*sc), P.GRAY, 0.28*sc)
        self.text(img, dist_str,
                  x0+p, y0+int(38*sc)+int(18*sc), P.ORANGE, 0.80*sc, 2, bold=True)

        ry = y0 + int(38*sc) + int(22*sc) + int(18*sc)
        lx = x0 + p
        vx = x0 + p + int(90*sc)
        for lbl, val, col in rows:
            self.text(img, lbl + ":", lx, ry, P.GRAY, 0.28*sc)
            self.text(img, val,       vx, ry, col,    0.28*sc)
            ry += rh

        # AI confidence bar
        if confidence > 0:
            bar_w = pw - p * 2
            bar_y = ry + int(8*sc)
            bar_h = max(6, int(8*sc))
            self.text(img, "AI confidence:", lx, bar_y, P.GRAY, 0.26*sc)
            bar_y2 = bar_y + int(4*sc)
            cv2.rectangle(img, (lx, bar_y2), (lx+bar_w, bar_y2+bar_h), P.BORDER, -1)
            cv2.rectangle(img, (lx, bar_y2),
                          (lx + int(bar_w*confidence), bar_y2+bar_h), P.YELLOW, -1)

        if at_max and max_range:
            self.text(img, f"(max range {max_range:,} m)",
                      x0+p, y1-4, (100,100,200), 0.26*sc)

    def status_bar(
        self,
        img,
        ai_ready:    bool,
        dem_on:      bool,
        depth_on:    bool,
    ) -> None:
        H, W = img.shape[:2]
        sc   = self.sc
        bh   = max(20, int(22*sc))
        cv2.rectangle(img, (0, H-bh), (W, H), P.DARK, -1)

        parts = [
            (f"AI: {'ready ✓' if ai_ready else 'loading…'}", P.GREEN if ai_ready else P.YELLOW),
            (f"DEM: {'on' if dem_on else 'off'}",             P.GREEN if dem_on else P.GRAY),
            (f"Depth: {'ON [D]' if depth_on else 'off [D]'}", P.ACCENT if depth_on else P.GRAY),
            ("Click=measure  R=reset  S=save  Q=quit",         P.GRAY),
        ]
        x = 8
        for label, col in parts:
            self.text(img, label, x, H-6, col, 0.26*sc)
            (tw, _), _ = cv2.getTextSize(label, FONT, 0.26*sc, 1)
            x += tw + int(24*sc)
