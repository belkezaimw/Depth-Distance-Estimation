"""
dfire.ui.wizard
===============
Full-screen OpenCV setup wizard.
Collects all camera parameters, DEM file, and image file,
validates them, then returns a populated Config object.
"""

from __future__ import annotations

import logging
import os
import sys
import time

import cv2
import numpy as np

from dfire.core.dem    import DEM
from dfire.utils.config import Config
from dfire.utils.drawing import DrawHelper, P, FONT, FONTB

log = logging.getLogger(__name__)

try:
    import tkinter as tk
    from tkinter import filedialog
    _HAS_TK = True
except ImportError:
    _HAS_TK = False

WIN = "DFire Distance Estimator — Setup"
W, H = 820, 660


# ── field definitions ─────────────────────────────────────────────────────────
_FIELDS = [
    ("Camera latitude  (°N)",           "camera_lat",        "36.731627",  "e.g.  36.7516"),
    ("Camera longitude (°E)",           "camera_lon",        "2.994820",   "e.g.   2.9942"),
    ("Camera elevation (m ASL)",        "camera_abs_elev_m", "14",         "ground + floor"),
    ("Camera tilt  (° negative=down)",  "camera_tilt_deg",   "-2",         "inclinometer"),
    ("Focal length  (px)",              "focal_length_px",   "1600",       "calibrate.py"),
    ("Pan / compass bearing  (°)",      "camera_pan_deg",    "0",          "0=N  90=E"),
    ("Max search range  (m)",           "max_range_m",       "6000",       "6000 for hills"),
    ("Valley / ground floor  (m ASL)",  "valley_floor_m",    "0",          "lowest terrain"),
    ("DEM file  (.tif or .hgt)",        "dem_path",          "",           "Browse →"),
    ("Image file",                      "image_path",        "",           "Browse →"),
]

_FILE_KEYS = {"dem_path", "image_path"}


class SetupWizard:
    """
    OpenCV-based setup form.

    Usage
    -----
    >>> wizard = SetupWizard(default_cfg)
    >>> result = wizard.run()   # blocks until user clicks START
    >>> cfg, dem, image = result["cfg"], result["dem"], result["image"]
    """

    def __init__(self, default_cfg: Config) -> None:
        self._vals   = {f[1]: f[2] for f in _FIELDS}
        # Pre-fill from config / env
        for f in _FIELDS:
            key = f[1]
            val = getattr(default_cfg, key, None)
            if val is not None:
                self._vals[key] = str(val)

        self._active  = 0
        self._typing  = self._vals[_FIELDS[0][1]]
        self._error   = ""
        self._result  = None
        self._dh      = DrawHelper(W)

        cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(WIN, W, H)
        cv2.setMouseCallback(WIN, self._on_mouse)

    # ── rendering ─────────────────────────────────────────────────────────────

    def _draw(self) -> None:
        img = np.full((H, W, 3), P.BG, dtype=np.uint8)

        # header
        cv2.rectangle(img, (0, 0), (W, 74), P.PANEL, -1)
        cv2.line(img, (0, 74), (W, 74), P.BORDER, 1)
        cv2.rectangle(img, (0, 0), (5, 74), P.ACCENT, -1)
        self._dh.text(img, "DFIRE DISTANCE ESTIMATOR", 22, 32, P.ACCENT, 0.68, 2, bold=True)
        self._dh.text(img, "AI + DEM Edition  —  Camera Setup", 24, 58, P.GRAY, 0.36)

        # fields — 2 columns
        cw = (W - 60) // 2
        for i, (label, key, _, hint) in enumerate(_FIELDS):
            col = i % 2
            row = i // 2
            x0  = 20 + col * (cw + 20)
            y0  = 90 + row * 102
            act = (i == self._active)
            val = self._typing if act else self._vals[key]

            cv2.rectangle(img, (x0, y0), (x0+cw, y0+86), P.PANEL, -1)
            bc = P.ACCENT if act else P.BORDER
            bth = 2 if act else 1
            cv2.rectangle(img, (x0, y0), (x0+cw, y0+86), bc, bth)

            self._dh.text(img, label, x0+10, y0+22, P.GRAY, 0.32)
            disp = val if val else hint
            col2 = P.WHITE if val else (55, 60, 80)
            # truncate long paths
            if len(disp) > 44:
                disp = "…" + disp[-43:]
            self._dh.text(img, disp, x0+10, y0+52, col2, 0.38)

            # blinking cursor
            if act and int(time.time() * 2) % 2 == 0:
                (tw, _), _ = cv2.getTextSize(val, FONT, 0.38, 1)
                cx2 = x0 + 10 + tw + 2
                cv2.line(img, (cx2, y0+36), (cx2, y0+60), P.ACCENT, 2)

            # browse button
            if key in _FILE_KEYS:
                bx = x0 + cw - 76
                by = y0 + 64
                cv2.rectangle(img, (bx, by), (bx+68, by+18), P.BORDER, -1)
                cv2.rectangle(img, (bx, by), (bx+68, by+18), P.ACCENT, 1)
                self._dh.text(img, "Browse", bx+10, by+13, P.ACCENT, 0.30)

        # error box
        if self._error:
            ey = H - 76
            cv2.rectangle(img, (18, ey), (W-18, ey+24), (30, 20, 40), -1)
            cv2.rectangle(img, (18, ey), (W-18, ey+24), P.RED, 1)
            self._dh.text(img, self._error, 28, ey+16, P.RED, 0.35)

        # START button
        bw, bh_btn = 260, 50
        bx_btn = (W - bw) // 2
        by_btn = H - 52
        cv2.rectangle(img, (bx_btn, by_btn), (bx_btn+bw, by_btn+bh_btn), P.ACCENT, -1)
        self._dh.text(img, "START  ▶", bx_btn+64, by_btn+32, P.DARK, 0.62, 2, bold=True)

        # tip
        self._dh.text(
            img,
            "Click field to edit  ·  Tab = next  ·  Enter = start",
            20, H - 6, P.BORDER, 0.28,
        )

        cv2.imshow(WIN, img)

    # ── event handlers ────────────────────────────────────────────────────────

    def _on_mouse(self, ev, x, y, *_) -> None:
        if ev != cv2.EVENT_LBUTTONDOWN:
            return
        cw = (W - 60) // 2

        # START button
        bw, bh_btn = 260, 50
        bx_btn = (W - bw) // 2
        by_btn = H - 52
        if bx_btn <= x <= bx_btn+bw and by_btn <= y <= by_btn+bh_btn:
            self._commit()
            return

        for i, (_, key, _, _) in enumerate(_FIELDS):
            col = i % 2
            row = i // 2
            x0  = 20 + col*(cw+20)
            y0  = 90 + row*102
            if x0 <= x <= x0+cw and y0 <= y <= y0+86:
                # save current field
                self._vals[_FIELDS[self._active][1]] = self._typing
                self._active = i
                self._typing = self._vals[key]
                # browse click
                if key in _FILE_KEYS:
                    bx = x0+cw-76; by = y0+64
                    if bx <= x <= bx+68 and by <= y <= by+18:
                        self._browse(key)
                break

    def _browse(self, key: str) -> None:
        if not _HAS_TK:
            return
        root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
        if key == "dem_path":
            path = filedialog.askopenfilename(
                title="Select DEM file",
                filetypes=[("DEM files", "*.tif *.tiff *.hgt *.img"), ("All", "*.*")],
            )
        else:
            path = filedialog.askopenfilename(
                title="Select camera image",
                filetypes=[("Images", "*.jpg *.jpeg *.png *.bmp"), ("All", "*.*")],
            )
        root.destroy()
        if path:
            self._vals[_FIELDS[self._active][1]] = self._typing
            self._vals[key] = path
            self._typing    = path

    def _handle_key(self, k: int) -> None:
        if k == 9:      # Tab
            self._vals[_FIELDS[self._active][1]] = self._typing
            self._active = (self._active + 1) % len(_FIELDS)
            self._typing = self._vals[_FIELDS[self._active][1]]
        elif k == 13:   # Enter
            self._commit()
        elif k in (8, 127):   # Backspace
            self._typing = self._typing[:-1]
        elif 32 <= k < 127:
            self._typing += chr(k)

    # ── validation ────────────────────────────────────────────────────────────

    def _commit(self) -> None:
        self._vals[_FIELDS[self._active][1]] = self._typing
        self._error = ""

        # Parse numeric fields
        numeric = {}
        num_keys = [
            "camera_lat", "camera_lon", "camera_abs_elev_m", "camera_tilt_deg",
            "focal_length_px", "camera_pan_deg", "max_range_m", "valley_floor_m",
        ]
        for key in num_keys:
            try:
                numeric[key] = float(self._vals[key])
            except ValueError:
                self._error = f"'{key}' must be a number (got: {self._vals[key]!r})"
                return

        if numeric["focal_length_px"] < 10:
            self._error = "Focal length must be > 10 px"
            return

        # Load image
        img_path = self._vals["image_path"].strip()
        if not img_path or not os.path.exists(img_path):
            self._error = "Image file not found — check the path or use Browse"
            return
        image = cv2.imread(img_path)
        if image is None:
            self._error = "Cannot open image file (unsupported format?)"
            return

        # Load DEM (optional)
        dem = None
        dem_path = self._vals["dem_path"].strip()
        if dem_path:
            if not os.path.exists(dem_path):
                self._error = "DEM file not found — check the path or leave blank"
                return
            try:
                dem = DEM(dem_path)
            except Exception as exc:
                self._error = f"DEM error: {exc}"
                return

        cfg = Config(**numeric)
        cfg.image_width_px  = image.shape[1]
        cfg.image_height_px = image.shape[0]
        cfg.dem_path        = dem_path

        self._result = {
            "cfg":        cfg,
            "dem":        dem,
            "image":      image,
            "image_path": img_path,
        }
        log.info("Setup complete — image %dx%d  DEM: %s",
                 image.shape[1], image.shape[0],
                 os.path.basename(dem_path) if dem_path else "none")

    # ── run loop ──────────────────────────────────────────────────────────────

    def run(self) -> dict:
        """Block until the user clicks START. Returns result dict."""
        while self._result is None:
            self._draw()
            k = cv2.waitKey(500) & 0xFF
            if k in (ord("q"), 27):
                cv2.destroyAllWindows()
                sys.exit(0)
            elif k != 255:
                self._handle_key(k)

        cv2.destroyWindow(WIN)
        return self._result
