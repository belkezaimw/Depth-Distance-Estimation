# DFire Distance Estimator — AI + DEM Edition

Click any point in a surveillance camera image → get the real-world distance
from the camera, using **Depth Anything V2** (AI) fused with **SRTM DEM terrain data**.

---

## Quick start

```bash
# 1. Clone / download the project
cd dfire_estimator

# 2. Run the setup script (creates .venv, installs deps, copies .env)
bash scripts/setup_env.sh          # Linux / macOS
scripts\setup_env.bat              # Windows

# 3. Edit .env with your camera parameters (see below)

# 4. Put your DEM file in data/dem/
#    Download: https://dem.copernicus.eu  or  https://earthexplorer.usgs.gov

# 5. Launch
source .venv/bin/activate          # Linux / macOS
.venv\Scripts\activate             # Windows

dfire                              # opens the setup wizard
```

---

## Setup wizard

The wizard collects all required parameters before opening the image:

| Field | Description | How to get it |
|-------|-------------|---------------|
| Camera latitude/longitude | GPS position of the camera | Google Maps → long press |
| Camera elevation (m ASL)  | Absolute elevation of camera | Google Earth + floor height |
| Camera tilt (°)           | How far down the camera points | Phone inclinometer app |
| Focal length (px)         | From calibration or spec sheet | `dfire calibrate --photos folder/` |
| Pan / bearing             | Compass direction camera faces | Compass app |
| Max range (m)             | Furthest distance to search | 6000 for hills, 500 for urban |
| DEM file                  | Terrain elevation map | See below |
| Image file                | Your camera photo | Browse |

---

## DEM file

Download a free SRTM tile for your area:

**Copernicus DEM** (recommended, 30 m resolution):
→ https://dem.copernicus.eu

**NASA SRTM via USGS EarthExplorer** (also free, 30 m):
→ https://earthexplorer.usgs.gov
→ Select your area → Data Sets → Digital Elevation → SRTM 1 Arc-Second

For **Algeria / Blida** (lat 36.73°N, lon 2.99°E), download tile `srtm_37_04.tif`
and place it in `data/dem/`.

---

## Controls (measurement window)

| Key | Action |
|-----|--------|
| Left-click | Measure distance to that point |
| D | Toggle AI depth map overlay |
| R | Reset measurement + clear AI anchors |
| S | Save annotated image to `output/` |
| Q / Escape | Quit |

The **Live Settings** window has 5 trackbars that update the measurement instantly.

---

## How it works

### DEM + Ray casting (always active)

1. Click pixel (px, py)
2. Compute elevation angle: `el = camera_tilt − atan2(py − cy, focal)`
3. March a ray from the camera at that angle, step by step
4. At each step, look up real terrain elevation from the DEM file
5. When ray elevation ≤ terrain elevation → hit point found
6. `dist_3D = √(horizontal² + elevation_drop²)`

**Accuracy**: ±10–30 m depending on DEM resolution

### AI Depth (Depth Anything V2, runs in background)

1. On image load, runs Depth Anything V2 → relative depth map (per pixel)
2. When you click a point with DEM active, that click is used as an anchor:
   `scale = DEM_distance × relative_depth_value`
3. After ≥1 anchor: absolute distances available for every pixel
4. Confidence bar fills as you click more points (saturates at 10 anchors)
5. Press **D** to see the depth map overlaid on the image

**Accuracy**: ±5–15 m after 5+ anchors (better than pure DEM on complex terrain)

---

## CLI usage

```bash
# Launch wizard (default)
dfire

# Skip wizard, provide everything via CLI
dfire run \
  --image  data/images/cam.jpg \
  --dem    data/dem/srtm-37-04.tif \
  --lat    36.731627 \
  --lon    2.994820 \
  --elev   14 \
  --tilt   -2 \
  --focal  1600

# Use larger, more accurate AI model (~400 MB)
dfire run --large-ai --image cam.jpg ...

# Calibrate focal length from chessboard photos
dfire calibrate --photos calib_photos/

# Show current config from .env
dfire info
```

---

## Project structure

```
dfire_estimator/
├── dfire/
│   ├── core/
│   │   ├── dem.py        ← DEM elevation lookup (.tif and .hgt)
│   │   ├── raycast.py    ← geometric ray casting engine
│   │   └── depth.py      ← Depth Anything V2 wrapper
│   ├── ui/
│   │   ├── wizard.py     ← setup wizard (OpenCV form)
│   │   └── measure.py    ← measurement window + trackbars
│   ├── utils/
│   │   ├── config.py     ← typed config + .env loading
│   │   ├── logger.py     ← coloured console logging
│   │   └── drawing.py    ← resolution-aware OpenCV helpers
│   └── cli.py            ← click CLI entry point (`dfire` command)
├── tests/
│   ├── test_raycast.py
│   ├── test_dem.py
│   └── test_config.py
├── scripts/
│   ├── setup_env.sh      ← Unix setup (venv + install)
│   └── setup_env.bat     ← Windows setup
├── data/
│   ├── dem/              ← put your .tif or .hgt file here
│   └── images/           ← put your camera images here
├── models/               ← AI model cache (auto-populated)
├── output/               ← saved result images
├── .env.example          ← copy to .env and fill in your values
├── .gitignore
├── pyproject.toml        ← modern Python package definition
└── README.md
```

---

## Running tests

```bash
# Activate venv first, then:
pytest                    # run all tests
pytest -v                 # verbose
pytest tests/test_dem.py  # single file
pytest --cov=dfire        # with coverage report
```

---

## Camera calibration

To get an accurate focal length:

```bash
# 1. Print the chessboard
python -c "
import cv2, numpy as np
board = np.kron([[1,0]*5,[0,1]*5]*5, np.ones((60,60)))*255
cv2.imwrite('chessboard.png', board.astype('uint8'))
print('Print chessboard.png')
"

# 2. Take 15-20 photos of the board from different angles
# 3. Run calibration
dfire calibrate --photos calib_photos/ --square 30

# 4. Add the focal length to .env
# DFIRE_FOCAL_LENGTH_PX=1623
```
